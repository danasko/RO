data = load('ex2data1.txt');
X = data(:, [1, 2]); y = data(:, 3);

fprintf(['Plotting data with + indicating (y = 1) examples and o ' ...
         'indicating (y = 0) examples.\n']);

figure; hold on;
pos = find(y == 1);
neg = find(y == 0);
plot(X(pos, 1), X(pos, 2), 'r.');
plot(X(neg, 1), X(neg, 2), 'y+');
hold off;

figure; hold on;
pos = find(y == 1);
neg = find(y == 0);
plot(X(pos, 1), X(pos, 2), 'r.');
plot(X(neg, 1), X(neg, 2), 'y+');

[m, n] = size(X);
X = [ones(m, 1) X];
initial_theta = zeros(n + 1, 1);
[cost, grad] = costFunction(initial_theta, X, y);

options = optimset('GradObj', 'on', 'MaxIter', 400);
[theta, cost] =	fminunc(@(t)(costFunction(t, X, y)), initial_theta, options)

if size(X, 2) <= 3
    plot_x = [min(X(:,2))-2,  max(X(:,2))+2];
    plot_y = (-1./theta(3)).*(theta(2).*plot_x + theta(1));
    plot(plot_x, plot_y)
    axis([30, 100, 30, 100])
end
hold off;


m = size(X, 1); 
p = zeros(m, 1);
h_theta = 1 ./ (1 + 1 ./ exp(X*theta));
index = find(h_theta >= 0.5);
p(index,1) = 1;

fprintf('Train Accuracy: %f\n', mean(double(p == y)) * 100);